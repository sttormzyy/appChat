/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import grupo10.messenger.backend.controlador.Control;

/**
 *
 * @author Usuario
 */
public class Main {
    public static void main(String[] args){
        Control control = Control.getInstance();
        
        control.registrar("SRECKO LA CONCHAD DE TU MADRE", "localHost", 4444);
        
        control.enviarMensaje("SRECKO PASA EL IG DE TU HIJA","localhost", 4444); //va a tirar error porque agregar contacto no esta codificado
    }
}
