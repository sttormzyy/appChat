package grupo10.messenger.backend.modelo;

import java.util.ArrayList;
import java.util.List;

public class Conversacion {
    private final Contacto contacto;
    private final List<Mensaje> mensajes;

    // Constructor
    public Conversacion(Contacto contacto) {
        this.contacto = contacto;
        this.mensajes = new ArrayList<>();
    }
    
    
    // 📌 Obtener la lista de mensajes
    public List<Mensaje> getMensajes() {
        return mensajes;
    }

    // 📌 Obtener el contacto asignado a la conversación
    public Contacto getContacto() {
        return contacto;
    }
    
    // 📌 Agregar un mensaje a la conversación
    public boolean agregarMensaje(Mensaje mensaje) {
        mensajes.add(mensaje);
        return true;
    }
    
}

