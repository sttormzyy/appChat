/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo10.messenger.backend.controlador;

import grupo10.messenger.backend.modelo.Contacto;
import grupo10.messenger.backend.modelo.Conversacion;
import grupo10.messenger.backend.modelo.Mensaje;
import grupo10.messenger.backend.modelo.MensajeRed;
import grupo10.messenger.backend.modelo.Usuario;
import grupo10.messenger.backend.red.Cliente;
import grupo10.messenger.backend.red.Server;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class Control {
    private static Control instance = null;
    private Usuario usuario;
    
    private Control(){}
    
    public static Control getInstance(){      
        if(instance == null)
            instance = new Control();
        return instance;
    }
    
    public boolean registrar(String nickname,String ip,int puerto){
        if (this.iniciarServer(puerto)){
            usuario = new Usuario(nickname,ip,puerto);
            return true;
        }
        return false;
    }
    
    private boolean iniciarServer(int puerto){
        
        Server server = new Server(puerto,instance);
        
        Thread hilo = new Thread(server);
        hilo.start();
        
        try {
            hilo.join(1000);//espero 1 seg para comprobar si se conecto o no el servidor al puerto
        } catch (InterruptedException ex) {
            return false;
        }
        return server.isConectado();
    }
    
    
    public synchronized boolean enviarMensaje(String contenido, String IP, int puerto){
       MensajeRed msjRed = new MensajeRed(usuario.getNickname(),usuario.getIp(),usuario.getPort(),IP,puerto,contenido);
       if (instance.enviarMensaje(msjRed)){
           Mensaje mensaje = new Mensaje(contenido,true);
           usuario.buscarConversacion(IP, puerto).agregarMensaje(mensaje);
           return true;
       }
       return false;
    }
    
    private boolean enviarMensaje(MensajeRed msj){
        Cliente cliente = new Cliente(msj);
        Thread hilo = new Thread(cliente);
        hilo.start();
        try {
            hilo.join(); //hilo principal de ejecucion espera a que el hilo cliente termine
        } catch (InterruptedException ex) {
            Logger.getLogger(Control.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(cliente.isConectado());
        return cliente.isConectado();
    }
    
    public synchronized void recibirMensaje(MensajeRed mensaje){
        Mensaje msj = new Mensaje(mensaje.getContenido(),true);
        Conversacion conversacion = usuario.buscarConversacion(mensaje.getMyIp(), mensaje.getMyPort());
        if( conversacion == null)
            conversacion = new Conversacion(new Contacto(mensaje.getMyNickname(),mensaje.getMyIp(),mensaje.getMyPort()));
        conversacion.agregarMensaje(msj);
        //llamar metodo de la vista
    }
}
