package grupo10.messenger.backend.modelo;

import java.util.ArrayList;


public class Usuario extends Persona {
    private ArrayList<Conversacion> conversaciones = null;
    private Agenda agenda = null;

    // Constructor
    public Usuario(String nickname, String ip, int port) {
        super(nickname, ip, port);
        this.conversaciones = new ArrayList();
        this.agenda = new Agenda();
    }

    // 📌 Obtener la agenda
    public Agenda getAgenda() {
        return agenda;
    }

    // 📌 Obtener lista de conversaciones
    public ArrayList<Conversacion> getConversaciones() {
        return conversaciones;
    }
    
    public boolean agregarConversacion(Conversacion conversacion) {
        conversaciones.add(conversacion);
    return true;
    }
    
    public Conversacion buscarConversacion(String ip, int puerto){
        int i = 0;
        while(i<conversaciones.size() && noEsConversacion(conversaciones.get(i),ip,puerto))
            i++;
        if(i<conversaciones.size())
            return conversaciones.get(i);
        return null;
    }
    
    private boolean noEsConversacion(Conversacion chat, String ip, int puerto){
        return (chat.getContacto().getIp().equals(ip) && puerto == chat.getContacto().getPort());
    }
    
    // 📌 Agregar un contacto a la agenda
    public boolean agregarContacto(Contacto contacto) {
        return agenda.agregarContacto(contacto);
    }

    // 📌 Eliminar un contacto de la agenda
    public boolean eliminarContacto(int id) {
        return agenda.eliminarContacto(id);
    }

    // 📌 Obtener un contacto de la agenda
    public Contacto obtenerContacto(int id) {
        return agenda.obtenerContactoPorId(id);
    }

    // 📌 Crear una nueva conversación con un contacto
    public Conversacion iniciarConversacion(Contacto contacto) {
        Conversacion nuevaConversacion = new Conversacion(contacto);

        if (this.agregarConversacion(nuevaConversacion)) { 
            return nuevaConversacion;
        }

        return null;
    }

}

